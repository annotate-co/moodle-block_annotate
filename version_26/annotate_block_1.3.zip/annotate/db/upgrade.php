<?php
/**
 * Handles upgrading instances of this block.
 *
 * @param int $oldversion
 * @param object $block
 */
function xmldb_block_annotate_upgrade($oldversion,$block) {
    return true;
}