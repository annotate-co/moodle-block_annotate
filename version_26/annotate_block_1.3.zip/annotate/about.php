<?php 
global $CFG;
$CFG->block_annotate_version_number="1.3";
$CFG->block_annotate_version_date="25-April-2015";
?>
