<?php 
?>

<html>
<head>
</head>
<body style="padding : 60px">
<h2>Error</h2>
<p>
There was a problem transferring to A.nnotate to view the document. Please contact
your server administrator.
</p>
</body>

</html>