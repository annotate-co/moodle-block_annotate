<?php
//see http://docs.moodle.org/dev/Releases
$plugin->version=2013112700;
$plugin->requires = 2012062500;
$plugin->maturity  = MATURITY_STABLE;
$plugin->release = '1.3.1';
$plugin->component = 'block_annotate';
