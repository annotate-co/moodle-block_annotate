<?php 
global $CFG;
$CFG->block_annotate_version_number="1.4.4";
$CFG->block_annotate_version_date="8-February-2014";
?>
